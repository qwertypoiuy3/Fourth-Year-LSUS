EntertainmentLibraryUI should be the startup project. 
Click the add button to add an element of the desired category. Likewise, click the delete button to delete it. 
Click the information button to display information for the selected book, movie, or videogame. 
Click refresh button after adding/deleting an item to update the listings.

*Stored Procedures

-spBooks_Delete, spMovies_Delete, spVideogames_Delete
	These stored procedures delete the selected book, movie, or videogame from their corresponding database.

-spBooks_GetAll, spMovie_GetAll, spVideogame_Getall
	These stored procedures return a list of all books, movies, or videogames in their corresponding database.

-spBooks_Insert, spMovies_Insert, spVideogames_Insert
	These stored procedures creates a book/movie/videogame entry in their corresponding database.