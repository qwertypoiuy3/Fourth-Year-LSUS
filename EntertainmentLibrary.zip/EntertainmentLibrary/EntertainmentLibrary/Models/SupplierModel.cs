﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntertainmentLibrary.Models
{
    public class SupplierModel
    {
        public int Id { get; set; }
        public string SupplierName { get; set; }
        public string SupplierURL { get; set; }
        public int GameId { get; set; }
        public int BookId { get; set; }
        public int VideogameId { get; set; }

        public SupplierModel(string name, string url)
        {
            SupplierName = name;
            SupplierURL = url;
        }

        public SupplierModel(string name, string url, int gameid)
        {
            SupplierName = name;
            SupplierURL = url;
            GameId = gameid;
        }
        public SupplierModel() { }
    }
}
