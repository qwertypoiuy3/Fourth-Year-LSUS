﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntertainmentLibrary.Models
{
    public class VideogameModel
    {
        public int Id { get; set; }
        public string GameName { get; set; }
        public string GameFormat { get; set; }
        public string GamePlatform { get; set; }
        public string GameRating { get; set; }
        public string SupplierName { get; set; }
        public VideogameModel (string name, string format, string platform, string rating, string supplierName)
        {
            GameName = name;
            GameFormat = format;
            GamePlatform = platform;
            GameRating = rating;
            SupplierName = supplierName;
        }
        public VideogameModel() { }
    }
}
