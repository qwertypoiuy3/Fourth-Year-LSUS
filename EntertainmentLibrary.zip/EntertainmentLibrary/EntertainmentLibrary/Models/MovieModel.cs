﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntertainmentLibrary.Models
{
    public class MovieModel
    {
        public int Id { get; set; }
        public string MovieName { get; set; }
        public string MovieFormat { get; set; }
        public string MovieGenre { get; set; }
        public string MovieLength { get; set; }
        public string MovieRating { get; set; }
        public string SupplierName { get; set; }
        public MovieModel( string name, string format, string genre, string rating, string supplierName)
        {
            MovieName = name;
            MovieFormat = format;
            MovieGenre = genre;
            MovieRating = rating;
            SupplierName = supplierName;
        }

        public MovieModel(){}

    }
}
