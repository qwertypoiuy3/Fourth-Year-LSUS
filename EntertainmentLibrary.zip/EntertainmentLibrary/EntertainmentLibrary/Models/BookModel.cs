﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntertainmentLibrary.Models
{
    public class BookModel
    {
        public int Id { get; set; }
        public string BookName { get; set; }
        public string BookFormat { get; set; }
        public string BookGenre { get; set; }
        public string BookRating { get; set; }
        public string SupplierName { get; set; }
        public BookModel(string name, string format, string genre, string rating, string supplierName)
        {
            BookName = name;
            BookFormat = format;
            BookGenre = genre;
            BookRating = rating;
            SupplierName = supplierName;
        }

        public BookModel() { }
    }
}
