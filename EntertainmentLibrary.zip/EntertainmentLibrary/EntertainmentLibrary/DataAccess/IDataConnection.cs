﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntertainmentLibrary.Models;

namespace EntertainmentLibrary.DataAccess
{
    public interface IDataConnection
    {
        MovieModel CreateMovie(MovieModel model);
        void DeleteMovie(MovieModel model);
        List<MovieModel> GetAllMovies();

        BookModel CreateBook(BookModel model);
        void DeleteBook(BookModel model);
        List<BookModel> GetAllBooks();

        VideogameModel CreateVideogame(VideogameModel model);
        void DeleteVideogame(VideogameModel model);
        List<VideogameModel> GetAllVideogames();

        SupplierModel CreateSupplier(SupplierModel model);
        void DeleteSupplier(SupplierModel model);
        List<SupplierModel> GetAllSuppliers();
    }
}
