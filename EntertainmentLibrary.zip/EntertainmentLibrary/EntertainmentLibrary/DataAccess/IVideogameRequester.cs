﻿using EntertainmentLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntertainmentLibrary.DataAccess
{
    public interface IVideogameRequester
    {
        void VideogameComplete(VideogameModel model);
    }
}
