﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using EntertainmentLibrary.Models;

namespace EntertainmentLibrary.DataAccess
{
    public class SqlConnector : IDataConnection
    {
        public MovieModel CreateMovie(MovieModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@MovieName", model.MovieName);
                p.Add("@MovieFormat", model.MovieFormat);
                p.Add("@MovieGenre", model.MovieGenre);
                p.Add("@MovieLength", model.MovieLength);
                p.Add("@MovieRating", model.MovieRating);
                p.Add("SupplierName", model.SupplierName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                connection.Execute("spMovies_Insert", p, commandType: CommandType.StoredProcedure);

                model.Id = p.Get<int>("@id");

                return model;
            }
        }
        public void DeleteMovie(MovieModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@MovieName", model.MovieName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);


                model.Id = p.Get<int>("id");

                connection.Execute("spMovies_Delete", p, commandType: CommandType.StoredProcedure);
            }
        }
        public List<MovieModel> GetAllMovies()
        {
            List<MovieModel> output;
            using(IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                output = connection.Query<MovieModel>("spMovie_GetAll").ToList();
            }
            return output;
        }


        public BookModel CreateBook(BookModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@BookName", model.BookName);
                p.Add("@BookFormat", model.BookFormat);
                p.Add("@BookGenre", model.BookGenre);
                p.Add("@BookRating", model.BookRating);
                p.Add("@SupplierName", model.SupplierName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                connection.Execute("spBooks_Insert", p, commandType: CommandType.StoredProcedure);

                model.Id = p.Get<int>("@id");

                return model;
            }
        }

        public void DeleteBook(BookModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@BookName", model.BookName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                model.Id = p.Get<int>("id");
                connection.Execute("spBooks_Delete", p, commandType: CommandType.StoredProcedure);

            }
        }

        public List<BookModel> GetAllBooks()
        {
            List<BookModel> output;
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                output = connection.Query<BookModel>("spBooks_GetAll").ToList();
            }
            return output;
        }

        public VideogameModel CreateVideogame(VideogameModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@VideogameName", model.GameName);
                p.Add("@VideogameFormat", model.GameFormat);
                p.Add("@VideogamePlatform", model.GamePlatform);
                p.Add("@VideogameRating", model.GameRating);
                p.Add("@SupplierName", model.SupplierName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                connection.Execute("spVideogames_Insert", p, commandType: CommandType.StoredProcedure);

                model.Id = p.Get<int>("@id");

                return model;
            }
        }

        public void DeleteVideogame(VideogameModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@VideogameName", model.GameName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);


                model.Id = p.Get<int>("id");

                connection.Execute("spVideogames_Delete", p, commandType: CommandType.StoredProcedure);

            }
        }

        public List<VideogameModel> GetAllVideogames()
        {
            List<VideogameModel> output;
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                output = connection.Query<VideogameModel>("spVideogame_GetAll").ToList();
            }
            return output;
        }

        public SupplierModel CreateSupplier(SupplierModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@SupplierName", model.SupplierName);
                p.Add("@SupplierURL", model.SupplierURL);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                connection.Execute("spSuppliers_Insert", p, commandType: CommandType.StoredProcedure);

                model.Id = p.Get<int>("@id");

                return model;
            }
        }

        public void DeleteSupplier(SupplierModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                var p = new DynamicParameters();
                p.Add("@SupplierName", model.SupplierName);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);


                model.Id = p.Get<int>("id");

                connection.Execute("spSuppliers_Delete", p, commandType: CommandType.StoredProcedure);

            }
        }

        public List<SupplierModel> GetAllSuppliers()
        {
            List<SupplierModel> output;
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString("EntertainmentLibrary")))
            {
                output = connection.Query<SupplierModel>("spSuppliers_GetAll").ToList();
            }
            return output;
        }
    }
}
