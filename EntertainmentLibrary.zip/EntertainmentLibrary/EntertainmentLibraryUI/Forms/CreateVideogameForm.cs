﻿using EntertainmentLibrary;
using EntertainmentLibrary.DataAccess;
using EntertainmentLibrary.Models;
using EntertainmentLibraryUI.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntertainmentLibraryUI
{
    public partial class CreateVideogameForm : Form, ISupplierRequester
    {
        private IVideogameRequester callingForm;

        List<SupplierModel> availableSuppliers = GlobalConfig.Connection.GetAllSuppliers();

        public CreateVideogameForm(IVideogameRequester caller)
        {
            InitializeComponent();
            this.callingForm = caller;
        }



        private void blurayButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        string ratingSelected;
        private void starpic5_Click(object sender, EventArgs e)
        {
            ratingSelected = "5";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.yellowstar;
            starpic5.Image = Resources.yellowstar;
        }
        private void starPic4_Click(object sender, EventArgs e)
        {
            ratingSelected = "4";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.yellowstar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic3_Click(object sender, EventArgs e)
        {
            ratingSelected = "3";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic2_Click(object sender, EventArgs e)
        {
            ratingSelected = "2";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.whitestar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic1_Click(object sender, EventArgs e)
        {
            ratingSelected = "1";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.whitestar;
            starpic3.Image = Resources.whitestar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        public string radioButton()
        {
            if (discButton.Checked) { return "Disc"; }
            if (cartridgeButton.Checked) { return "Cartridge"; }
            if (digitalButton.Checked) { return "Digital"; }
            return "";
        }


        private void addVideogameButton_Click(object sender, EventArgs e)
        {


            string formatSelected = radioButton();
            if (ValidateForm())
            {
                string platformValue = platformList.SelectedItem.ToString();
                VideogameModel model = new VideogameModel(videogameNameValue.Text, formatSelected, platformValue, ratingSelected, supplierList.Text);
                GlobalConfig.Connection.CreateVideogame(model);

                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter a Videogame Title, select a Format, and select a Platform.");
            }
        }

        private bool ValidateForm()
        {
            string formatSelected = radioButton();
            bool output = true;
            if (videogameNameValue.Text.Length == 0 || formatSelected == "" || platformList.SelectedItem == null)
            {
                output = false;
            }
            return output;

        }

        private void newSupplierLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CreateSupplierForm frm = new CreateSupplierForm(this);
            frm.Show();
        }

        public void SupplierComplete(SupplierModel model)
        {
            availableSuppliers.Add(model);

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            supplierList.DataSource = GlobalConfig.Connection.GetAllSuppliers();
            supplierList.DisplayMember = "SupplierName";
        }

        private void createNewPlatformLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter a new Platform", "Create new platform");
            if(input != "") { platformList.Items.Add(input); }
        }
    }
}
