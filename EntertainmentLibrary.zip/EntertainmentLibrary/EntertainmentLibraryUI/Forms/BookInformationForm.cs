﻿using EntertainmentLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntertainmentLibraryUI
{
    public partial class BookInformationForm : Form
    {
        public BookInformationForm(BookModel bookSelected)
        {
            
            InitializeComponent();
            bookTitle.Text = bookSelected.BookName;
            bookFormat.Text = "Format: " + bookSelected.BookFormat;
            bookGenre.Text = "Genre: " + bookSelected.BookGenre;
            if (bookSelected.BookRating == null)
            {
                bookRating.Text = "Rating: " + "0/5";
            }
            else { bookRating.Text = "Rating: " + bookSelected.BookRating + "/5"; }
            if (bookSelected.SupplierName == "")
            {
                supplierName.Text = null;
            }
            else { supplierName.Text = "Supplier: " + bookSelected.SupplierName; }
        }
        
    }
}
