﻿using EntertainmentLibrary;
using EntertainmentLibrary.DataAccess;
using EntertainmentLibrary.Models;
using EntertainmentLibraryUI.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EntertainmentLibraryUI
{
    public partial class CreateMovieForm : Form, ISupplierRequester
    {
        private IMovieRequester callingForm;

        List<SupplierModel> availableSuppliers = GlobalConfig.Connection.GetAllSuppliers();

        public CreateMovieForm(IMovieRequester caller)
        {
            InitializeComponent();
            this.callingForm = caller;
        }


        string ratingSelected;
        private void starpic5_Click(object sender, EventArgs e)
        {
            ratingSelected = "5";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.yellowstar;
            starpic5.Image = Resources.yellowstar;
        }
        private void starPic4_Click(object sender, EventArgs e)
        {
            ratingSelected = "4";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.yellowstar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic3_Click(object sender, EventArgs e)
        {
            ratingSelected = "3";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic2_Click(object sender, EventArgs e)
        {
            ratingSelected = "2";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.whitestar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic1_Click(object sender, EventArgs e)
        {
            ratingSelected = "1";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.whitestar;
            starpic3.Image = Resources.whitestar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }


        public string radioButton()
        {
            if (vhsButton.Checked) { return "VHS"; }
            if (dvdButton.Checked) { return "DVD"; }
            if (blurayButton.Checked) { return "BluRay"; }
            if (uhdButton.Checked) { return "4K BluRay"; }
            if (digitalButton.Checked) { return "Digital"; }
            return "";
        }

        private void addMovieButton_Click(object sender, EventArgs e)
        {
            string formatSelected = radioButton();

            if (ValidateForm())
            {
                MovieModel model = new MovieModel(movieNameValue.Text, formatSelected, movieGenreValue.Text, ratingSelected, supplierList.Text);
                GlobalConfig.Connection.CreateMovie(model);


                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter a Movie Title and select Movie Format.");
            }
        }

        private bool ValidateForm()
        {
            string formatSelected = radioButton();
            bool output = true;
            if (movieNameValue.Text.Length == 0 || formatSelected == "")
            {
                output = false;
            }
            return output;

        }

        private void CreateMovieForm_Load(object sender, EventArgs e)
        {

        }

        public void SupplierComplete(SupplierModel model)
        {
            availableSuppliers.Add(model);

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            supplierList.DataSource = GlobalConfig.Connection.GetAllSuppliers();
            supplierList.DisplayMember = "SupplierName";
        }

        private void newSupplierLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CreateSupplierForm frm = new CreateSupplierForm(this);
            frm.Show();
        }
    }
}
