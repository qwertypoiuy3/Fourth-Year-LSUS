﻿namespace EntertainmentLibraryUI
{
    partial class MovieInformationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            supplierName = new Label();
            movieRating = new Label();
            movieGenre = new Label();
            movieFormat = new Label();
            movieTitle = new Label();
            SuspendLayout();
            // 
            // supplierName
            // 
            supplierName.AutoSize = true;
            supplierName.Location = new Point(12, 275);
            supplierName.Name = "supplierName";
            supplierName.Size = new Size(190, 38);
            supplierName.TabIndex = 9;
            supplierName.Text = "supplierName";
            // 
            // movieRating
            // 
            movieRating.AutoSize = true;
            movieRating.Location = new Point(12, 224);
            movieRating.Name = "movieRating";
            movieRating.Size = new Size(158, 38);
            movieRating.TabIndex = 8;
            movieRating.Text = "bookRating";
            // 
            // movieGenre
            // 
            movieGenre.AutoSize = true;
            movieGenre.Location = new Point(12, 166);
            movieGenre.Name = "movieGenre";
            movieGenre.Size = new Size(154, 38);
            movieGenre.TabIndex = 7;
            movieGenre.Text = "bookGenre";
            // 
            // movieFormat
            // 
            movieFormat.AutoSize = true;
            movieFormat.Location = new Point(12, 110);
            movieFormat.Name = "movieFormat";
            movieFormat.Size = new Size(166, 38);
            movieFormat.TabIndex = 6;
            movieFormat.Text = "bookFormat";
            // 
            // movieTitle
            // 
            movieTitle.AutoSize = true;
            movieTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            movieTitle.ForeColor = Color.SlateBlue;
            movieTitle.Location = new Point(43, 32);
            movieTitle.Name = "movieTitle";
            movieTitle.Size = new Size(202, 54);
            movieTitle.TabIndex = 10;
            movieTitle.Text = "BookTitle";
            // 
            // MovieInformationForm
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(308, 365);
            Controls.Add(movieTitle);
            Controls.Add(supplierName);
            Controls.Add(movieRating);
            Controls.Add(movieGenre);
            Controls.Add(movieFormat);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.DarkViolet;
            Margin = new Padding(6);
            Name = "MovieInformationForm";
            Text = "MovieInformationForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label supplierName;
        private Label movieRating;
        private Label movieGenre;
        private Label movieFormat;
        private Label movieTitle;
    }
}