﻿using EntertainmentLibrary;
using EntertainmentLibrary.DataAccess;
using EntertainmentLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntertainmentLibraryUI
{
    public partial class LibraryForm : Form, IMovieRequester, IBookRequester, IVideogameRequester
    {
        List<MovieModel> availableMovies = GlobalConfig.Connection.GetAllMovies();

        List<BookModel> availableBooks = GlobalConfig.Connection.GetAllBooks();

        List<VideogameModel> availableVideogames = GlobalConfig.Connection.GetAllVideogames();

        private void WireUp()
        {
            movieList.DataSource = GlobalConfig.Connection.GetAllMovies();
            movieList.DisplayMember = "MovieName";

            bookList.DataSource = GlobalConfig.Connection.GetAllBooks();
            bookList.DisplayMember = "BookName";

            videogameList.DataSource = GlobalConfig.Connection.GetAllVideogames();
            videogameList.DisplayMember = "GameName";
        }

        public LibraryForm()
        {
            InitializeComponent();
            WireUp();
        }


        private void addMovie_Click(object sender, EventArgs e)
        {
            CreateMovieForm frm = new CreateMovieForm(this);
            frm.Show();
        }

        public void MovieComplete(MovieModel model)
        {
            availableMovies.Add(model);
            WireUp();
        }

        private void deleteMovie_Click(object sender, EventArgs e)
        {
            MovieModel m = (MovieModel)movieList.SelectedItem;

            if (m != null)
            {
                availableMovies.Remove(m);
                GlobalConfig.Connection.DeleteMovie(m);
            }
            
            WireUp();

        }
        private void movieInformation_Click(object sender, EventArgs e)
        {
            MovieInformationForm frm = new MovieInformationForm((MovieModel)movieList.SelectedItem);
            frm.Show();
        }
        private void LibraryForm_Load(object sender, EventArgs e)
        {

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            WireUp();
        }

        private void addBook_Click(object sender, EventArgs e)
        {
            CreateBookForm frm = new CreateBookForm(this);
            frm.Show();
        }

        public void BookComplete(BookModel model)
        {
            availableBooks.Add(model);
            WireUp();
        }

        private void deleteBook_Click(object sender, EventArgs e)
        {
            BookModel m = (BookModel)bookList.SelectedItem;

            if (m != null)
            {
                availableBooks.Remove(m);
                GlobalConfig.Connection.DeleteBook(m);

            }
            
            WireUp();
        }

        private void bookInformation_Click(object sender, EventArgs e)
        {
            BookInformationForm frm = new BookInformationForm((BookModel)bookList.SelectedItem);
            frm.Show();
        }

        private void addVideogame_Click(object sender, EventArgs e)
        {
            CreateVideogameForm frm = new CreateVideogameForm(this);
            frm.Show();
        }

        private void deleteVideogame_Click(object sender, EventArgs e)
        {
            VideogameModel m = (VideogameModel)videogameList.SelectedItem;

            if (m != null)
            {
                availableVideogames.Remove(m);
                GlobalConfig.Connection.DeleteVideogame(m);
            }
            
            WireUp();

        }

        public void VideogameComplete(VideogameModel model)
        {
            availableVideogames.Add(model);
            WireUp();
        }

        private void videogameInformation_Click(object sender, EventArgs e)
        {
            VideogameInformationForm frm = new VideogameInformationForm((VideogameModel)videogameList.SelectedItem);
            frm.Show();
        }

    }
}
