﻿namespace EntertainmentLibraryUI
{
    partial class CreateBookForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            headerLabel = new Label();
            bookNameLabel = new Label();
            bookNameValue = new TextBox();
            bookFormatLabel = new Label();
            paperbackButton = new RadioButton();
            hardcoverButton = new RadioButton();
            ebookButton = new RadioButton();
            bookGenreValue = new TextBox();
            bookGenreLabel = new Label();
            ratingLabel = new Label();
            starpic1 = new PictureBox();
            starpic2 = new PictureBox();
            starpic5 = new PictureBox();
            starpic4 = new PictureBox();
            starpic3 = new PictureBox();
            selectSupplierLabel = new Label();
            supplierList = new ComboBox();
            newSupplierLink = new LinkLabel();
            addBookButton = new Button();
            refreshButton = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)starpic1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).BeginInit();
            SuspendLayout();
            // 
            // headerLabel
            // 
            headerLabel.AutoSize = true;
            headerLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            headerLabel.Location = new Point(12, 9);
            headerLabel.Name = "headerLabel";
            headerLabel.Size = new Size(253, 54);
            headerLabel.TabIndex = 0;
            headerLabel.Text = "Create Book";
            // 
            // bookNameLabel
            // 
            bookNameLabel.AutoSize = true;
            bookNameLabel.ForeColor = Color.DarkViolet;
            bookNameLabel.Location = new Point(12, 94);
            bookNameLabel.Name = "bookNameLabel";
            bookNameLabel.Size = new Size(256, 41);
            bookNameLabel.TabIndex = 1;
            bookNameLabel.Text = "Enter Book Name:";
            // 
            // bookNameValue
            // 
            bookNameValue.BackColor = Color.Gainsboro;
            bookNameValue.BorderStyle = BorderStyle.FixedSingle;
            bookNameValue.Location = new Point(274, 94);
            bookNameValue.Name = "bookNameValue";
            bookNameValue.Size = new Size(318, 47);
            bookNameValue.TabIndex = 2;
            // 
            // bookFormatLabel
            // 
            bookFormatLabel.AutoSize = true;
            bookFormatLabel.ForeColor = Color.DarkViolet;
            bookFormatLabel.Location = new Point(12, 186);
            bookFormatLabel.Name = "bookFormatLabel";
            bookFormatLabel.Size = new Size(206, 41);
            bookFormatLabel.TabIndex = 3;
            bookFormatLabel.Text = "Select Format:";
            // 
            // paperbackButton
            // 
            paperbackButton.AutoSize = true;
            paperbackButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            paperbackButton.ForeColor = Color.RoyalBlue;
            paperbackButton.Location = new Point(244, 195);
            paperbackButton.Name = "paperbackButton";
            paperbackButton.Size = new Size(123, 32);
            paperbackButton.TabIndex = 4;
            paperbackButton.TabStop = true;
            paperbackButton.Text = "Paperback";
            paperbackButton.UseVisualStyleBackColor = true;
            // 
            // hardcoverButton
            // 
            hardcoverButton.AutoSize = true;
            hardcoverButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            hardcoverButton.ForeColor = Color.RoyalBlue;
            hardcoverButton.Location = new Point(373, 195);
            hardcoverButton.Name = "hardcoverButton";
            hardcoverButton.Size = new Size(124, 32);
            hardcoverButton.TabIndex = 5;
            hardcoverButton.TabStop = true;
            hardcoverButton.Text = "Hardcover";
            hardcoverButton.UseVisualStyleBackColor = true;
            // 
            // ebookButton
            // 
            ebookButton.AutoSize = true;
            ebookButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ebookButton.ForeColor = Color.RoyalBlue;
            ebookButton.Location = new Point(503, 195);
            ebookButton.Name = "ebookButton";
            ebookButton.Size = new Size(88, 32);
            ebookButton.TabIndex = 6;
            ebookButton.TabStop = true;
            ebookButton.Text = "eBook";
            ebookButton.UseVisualStyleBackColor = true;
            // 
            // bookGenreValue
            // 
            bookGenreValue.BackColor = Color.Gainsboro;
            bookGenreValue.BorderStyle = BorderStyle.FixedSingle;
            bookGenreValue.Location = new Point(274, 275);
            bookGenreValue.Name = "bookGenreValue";
            bookGenreValue.Size = new Size(318, 47);
            bookGenreValue.TabIndex = 8;
            // 
            // bookGenreLabel
            // 
            bookGenreLabel.AutoSize = true;
            bookGenreLabel.ForeColor = Color.DarkViolet;
            bookGenreLabel.Location = new Point(12, 275);
            bookGenreLabel.Name = "bookGenreLabel";
            bookGenreLabel.Size = new Size(257, 41);
            bookGenreLabel.TabIndex = 7;
            bookGenreLabel.Text = "Enter Book Genre:";
            // 
            // ratingLabel
            // 
            ratingLabel.AutoSize = true;
            ratingLabel.ForeColor = Color.DarkViolet;
            ratingLabel.Location = new Point(12, 364);
            ratingLabel.Name = "ratingLabel";
            ratingLabel.Size = new Size(110, 41);
            ratingLabel.TabIndex = 9;
            ratingLabel.Text = "Rating:";
            // 
            // starpic1
            // 
            starpic1.Image = Properties.Resources.whitestar;
            starpic1.Location = new Point(128, 367);
            starpic1.Name = "starpic1";
            starpic1.Size = new Size(43, 38);
            starpic1.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic1.TabIndex = 10;
            starpic1.TabStop = false;
            starpic1.Click += starPic1_Click;
            // 
            // starpic2
            // 
            starpic2.Image = Properties.Resources.whitestar;
            starpic2.Location = new Point(177, 367);
            starpic2.Name = "starpic2";
            starpic2.Size = new Size(43, 38);
            starpic2.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic2.TabIndex = 11;
            starpic2.TabStop = false;
            starpic2.Click += starPic2_Click;
            // 
            // starpic5
            // 
            starpic5.Image = Properties.Resources.whitestar;
            starpic5.Location = new Point(324, 367);
            starpic5.Name = "starpic5";
            starpic5.Size = new Size(43, 38);
            starpic5.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic5.TabIndex = 12;
            starpic5.TabStop = false;
            starpic5.Click += starpic5_Click;
            // 
            // starpic4
            // 
            starpic4.Image = Properties.Resources.whitestar;
            starpic4.Location = new Point(275, 367);
            starpic4.Name = "starpic4";
            starpic4.Size = new Size(43, 38);
            starpic4.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic4.TabIndex = 13;
            starpic4.TabStop = false;
            starpic4.Click += starPic4_Click;
            // 
            // starpic3
            // 
            starpic3.Image = Properties.Resources.whitestar;
            starpic3.Location = new Point(226, 367);
            starpic3.Name = "starpic3";
            starpic3.Size = new Size(43, 38);
            starpic3.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic3.TabIndex = 14;
            starpic3.TabStop = false;
            starpic3.Click += starPic3_Click;
            // 
            // selectSupplierLabel
            // 
            selectSupplierLabel.AutoSize = true;
            selectSupplierLabel.ForeColor = Color.DarkViolet;
            selectSupplierLabel.Location = new Point(12, 437);
            selectSupplierLabel.Name = "selectSupplierLabel";
            selectSupplierLabel.Size = new Size(221, 41);
            selectSupplierLabel.TabIndex = 15;
            selectSupplierLabel.Text = "Select Supplier:";
            // 
            // supplierList
            // 
            supplierList.BackColor = Color.Gainsboro;
            supplierList.DropDownStyle = ComboBoxStyle.DropDownList;
            supplierList.FormattingEnabled = true;
            supplierList.Location = new Point(226, 434);
            supplierList.Name = "supplierList";
            supplierList.Size = new Size(271, 49);
            supplierList.TabIndex = 16;
            // 
            // newSupplierLink
            // 
            newSupplierLink.AutoSize = true;
            newSupplierLink.Location = new Point(109, 496);
            newSupplierLink.Name = "newSupplierLink";
            newSupplierLink.Size = new Size(258, 41);
            newSupplierLink.TabIndex = 17;
            newSupplierLink.TabStop = true;
            newSupplierLink.Text = "Add New Supplier";
            newSupplierLink.LinkClicked += newSupplierLink_LinkClicked;
            // 
            // addBookButton
            // 
            addBookButton.BackColor = Color.PaleGreen;
            addBookButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            addBookButton.ForeColor = SystemColors.ActiveCaptionText;
            addBookButton.Location = new Point(538, 472);
            addBookButton.Name = "addBookButton";
            addBookButton.Size = new Size(205, 65);
            addBookButton.TabIndex = 18;
            addBookButton.Text = "Add Book";
            addBookButton.UseVisualStyleBackColor = false;
            addBookButton.Click += addBookButton_Click;
            // 
            // refreshButton
            // 
            refreshButton.Image = Properties.Resources.refresh1;
            refreshButton.Location = new Point(697, 9);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(66, 64);
            refreshButton.SizeMode = PictureBoxSizeMode.StretchImage;
            refreshButton.TabIndex = 45;
            refreshButton.TabStop = false;
            refreshButton.Click += refreshButton_Click;
            // 
            // CreateBookForm
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(775, 564);
            Controls.Add(refreshButton);
            Controls.Add(addBookButton);
            Controls.Add(newSupplierLink);
            Controls.Add(supplierList);
            Controls.Add(selectSupplierLabel);
            Controls.Add(starpic3);
            Controls.Add(starpic4);
            Controls.Add(starpic5);
            Controls.Add(starpic2);
            Controls.Add(starpic1);
            Controls.Add(ratingLabel);
            Controls.Add(bookGenreValue);
            Controls.Add(bookGenreLabel);
            Controls.Add(ebookButton);
            Controls.Add(hardcoverButton);
            Controls.Add(paperbackButton);
            Controls.Add(bookFormatLabel);
            Controls.Add(bookNameValue);
            Controls.Add(bookNameLabel);
            Controls.Add(headerLabel);
            Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.CornflowerBlue;
            Margin = new Padding(6);
            Name = "CreateBookForm";
            Text = "Create Book";
            ((System.ComponentModel.ISupportInitialize)starpic1).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic2).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic5).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic4).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic3).EndInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label headerLabel;
        private Label bookNameLabel;
        private TextBox bookNameValue;
        private Label bookFormatLabel;
        private RadioButton paperbackButton;
        private RadioButton hardcoverButton;
        private RadioButton ebookButton;
        private TextBox bookGenreValue;
        private Label bookGenreLabel;
        private Label ratingLabel;
        private PictureBox starpic1;
        private PictureBox starpic2;
        private PictureBox starpic5;
        private PictureBox starpic4;
        private PictureBox starpic3;
        private Label selectSupplierLabel;
        private ComboBox supplierList;
        private LinkLabel newSupplierLink;
        private Button addBookButton;
        private PictureBox refreshButton;
    }
}