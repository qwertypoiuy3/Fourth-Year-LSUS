using EntertainmentLibrary;
using EntertainmentLibrary.DataAccess;
using EntertainmentLibrary.Models;
using EntertainmentLibraryUI.Properties;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace EntertainmentLibraryUI
{
    public partial class CreateBookForm : Form, ISupplierRequester
    {

        private IBookRequester callingForm;

        List<SupplierModel> availableSuppliers = GlobalConfig.Connection.GetAllSuppliers();

        public CreateBookForm(IBookRequester caller)
        {
            InitializeComponent();
            this.callingForm = caller;
        }

        string ratingSelected;
        private void starpic5_Click(object sender, EventArgs e)
        {
            ratingSelected = "5";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.yellowstar;
            starpic5.Image = Resources.yellowstar;
        }
        private void starPic4_Click(object sender, EventArgs e)
        {
            ratingSelected = "4";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.yellowstar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic3_Click(object sender, EventArgs e)
        {
            ratingSelected = "3";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.yellowstar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic2_Click(object sender, EventArgs e)
        {
            ratingSelected = "2";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.yellowstar;
            starpic3.Image = Resources.whitestar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }

        private void starPic1_Click(object sender, EventArgs e)
        {
            ratingSelected = "1";
            starpic1.Image = Resources.yellowstar;
            starpic2.Image = Resources.whitestar;
            starpic3.Image = Resources.whitestar;
            starpic4.Image = Resources.whitestar;
            starpic5.Image = Resources.whitestar;
        }
        public string radioButton()
        {
            if (paperbackButton.Checked) { return "Paperback"; }
            if (hardcoverButton.Checked) { return "Hardcover"; }
            if (ebookButton.Checked) { return "eBook"; }
            return "";
        }
        private void addBookButton_Click(object sender, EventArgs e)
        {
            string formatSelected = radioButton();
            if (ValidateForm())
            {
                BookModel model = new BookModel(bookNameValue.Text, formatSelected, bookGenreValue.Text, ratingSelected, supplierList.Text);
                GlobalConfig.Connection.CreateBook(model);

                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter a Book Title and select Book Format.");
            }

        }

        private bool ValidateForm()
        {
            string formatSelected = radioButton();
            bool output = true;
            if (bookNameValue.Text.Length == 0 || formatSelected == "")
            {
                output = false;
            }
            return output;

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            supplierList.DataSource = GlobalConfig.Connection.GetAllSuppliers();
            supplierList.DisplayMember = "SupplierName";
        }

        public void SupplierComplete(SupplierModel model)
        {
            availableSuppliers.Add(model);

        }

        private void newSupplierLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CreateSupplierForm frm = new CreateSupplierForm(this);
            frm.Show();
        }
    }
}