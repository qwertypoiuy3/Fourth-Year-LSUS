﻿namespace EntertainmentLibraryUI
{
    partial class LibraryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            headerLabel = new Label();
            moviesLabel = new Label();
            booksLabel = new Label();
            videogamesLabel = new Label();
            bookList = new ListBox();
            movieList = new ListBox();
            videogameList = new ListBox();
            addBook = new PictureBox();
            addMovie = new PictureBox();
            addVideogame = new PictureBox();
            bookInformation = new PictureBox();
            movieInformation = new PictureBox();
            videogameInformation = new PictureBox();
            deleteBook = new PictureBox();
            deleteMovie = new PictureBox();
            deleteVideogame = new PictureBox();
            refreshButton = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)addBook).BeginInit();
            ((System.ComponentModel.ISupportInitialize)addMovie).BeginInit();
            ((System.ComponentModel.ISupportInitialize)addVideogame).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bookInformation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)movieInformation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)videogameInformation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)deleteBook).BeginInit();
            ((System.ComponentModel.ISupportInitialize)deleteMovie).BeginInit();
            ((System.ComponentModel.ISupportInitialize)deleteVideogame).BeginInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).BeginInit();
            SuspendLayout();
            // 
            // headerLabel
            // 
            headerLabel.AutoSize = true;
            headerLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            headerLabel.ForeColor = Color.CornflowerBlue;
            headerLabel.Location = new Point(328, 9);
            headerLabel.Name = "headerLabel";
            headerLabel.Size = new Size(440, 54);
            headerLabel.TabIndex = 20;
            headerLabel.Text = "Entertainment Library";
            // 
            // moviesLabel
            // 
            moviesLabel.AutoSize = true;
            moviesLabel.ForeColor = Color.DarkViolet;
            moviesLabel.Location = new Point(384, 102);
            moviesLabel.Name = "moviesLabel";
            moviesLabel.Size = new Size(120, 41);
            moviesLabel.TabIndex = 23;
            moviesLabel.Text = "Movies:";
            // 
            // booksLabel
            // 
            booksLabel.AutoSize = true;
            booksLabel.ForeColor = Color.DarkViolet;
            booksLabel.Location = new Point(12, 102);
            booksLabel.Name = "booksLabel";
            booksLabel.Size = new Size(106, 41);
            booksLabel.TabIndex = 24;
            booksLabel.Text = "Books:";
            // 
            // videogamesLabel
            // 
            videogamesLabel.AutoSize = true;
            videogamesLabel.ForeColor = Color.DarkViolet;
            videogamesLabel.Location = new Point(765, 102);
            videogamesLabel.Name = "videogamesLabel";
            videogamesLabel.Size = new Size(191, 41);
            videogamesLabel.TabIndex = 25;
            videogamesLabel.Text = "Videogames:";
            // 
            // bookList
            // 
            bookList.BackColor = Color.Gainsboro;
            bookList.BorderStyle = BorderStyle.FixedSingle;
            bookList.FormattingEnabled = true;
            bookList.ItemHeight = 41;
            bookList.Location = new Point(12, 146);
            bookList.Name = "bookList";
            bookList.Size = new Size(258, 248);
            bookList.TabIndex = 26;
            // 
            // movieList
            // 
            movieList.BackColor = Color.Gainsboro;
            movieList.BorderStyle = BorderStyle.FixedSingle;
            movieList.FormattingEnabled = true;
            movieList.ItemHeight = 41;
            movieList.Location = new Point(384, 146);
            movieList.Name = "movieList";
            movieList.Size = new Size(258, 248);
            movieList.TabIndex = 27;
            // 
            // videogameList
            // 
            videogameList.BackColor = Color.Gainsboro;
            videogameList.BorderStyle = BorderStyle.FixedSingle;
            videogameList.FormattingEnabled = true;
            videogameList.ItemHeight = 41;
            videogameList.Location = new Point(765, 146);
            videogameList.Name = "videogameList";
            videogameList.Size = new Size(258, 248);
            videogameList.TabIndex = 28;
            // 
            // addBook
            // 
            addBook.Image = Properties.Resources.addnew;
            addBook.Location = new Point(276, 146);
            addBook.Name = "addBook";
            addBook.Size = new Size(58, 58);
            addBook.SizeMode = PictureBoxSizeMode.StretchImage;
            addBook.TabIndex = 29;
            addBook.TabStop = false;
            addBook.Click += addBook_Click;
            // 
            // addMovie
            // 
            addMovie.Image = Properties.Resources.addnew;
            addMovie.Location = new Point(648, 146);
            addMovie.Name = "addMovie";
            addMovie.Size = new Size(58, 58);
            addMovie.SizeMode = PictureBoxSizeMode.StretchImage;
            addMovie.TabIndex = 30;
            addMovie.TabStop = false;
            addMovie.Click += addMovie_Click;
            // 
            // addVideogame
            // 
            addVideogame.Image = Properties.Resources.addnew;
            addVideogame.Location = new Point(1029, 146);
            addVideogame.Name = "addVideogame";
            addVideogame.Size = new Size(58, 58);
            addVideogame.SizeMode = PictureBoxSizeMode.StretchImage;
            addVideogame.TabIndex = 31;
            addVideogame.TabStop = false;
            addVideogame.Click += addVideogame_Click;
            // 
            // bookInformation
            // 
            bookInformation.Image = Properties.Resources.informationicon;
            bookInformation.Location = new Point(277, 251);
            bookInformation.Name = "bookInformation";
            bookInformation.Size = new Size(55, 55);
            bookInformation.SizeMode = PictureBoxSizeMode.StretchImage;
            bookInformation.TabIndex = 32;
            bookInformation.TabStop = false;
            bookInformation.Click += bookInformation_Click;
            // 
            // movieInformation
            // 
            movieInformation.Image = Properties.Resources.informationicon;
            movieInformation.Location = new Point(648, 251);
            movieInformation.Name = "movieInformation";
            movieInformation.Size = new Size(55, 55);
            movieInformation.SizeMode = PictureBoxSizeMode.StretchImage;
            movieInformation.TabIndex = 33;
            movieInformation.TabStop = false;
            movieInformation.Click += movieInformation_Click;
            // 
            // videogameInformation
            // 
            videogameInformation.Image = Properties.Resources.informationicon;
            videogameInformation.Location = new Point(1029, 251);
            videogameInformation.Name = "videogameInformation";
            videogameInformation.Size = new Size(55, 55);
            videogameInformation.SizeMode = PictureBoxSizeMode.StretchImage;
            videogameInformation.TabIndex = 34;
            videogameInformation.TabStop = false;
            videogameInformation.Click += videogameInformation_Click;
            // 
            // deleteBook
            // 
            deleteBook.Image = Properties.Resources.deleteselected;
            deleteBook.Location = new Point(272, 353);
            deleteBook.Name = "deleteBook";
            deleteBook.Size = new Size(59, 59);
            deleteBook.SizeMode = PictureBoxSizeMode.StretchImage;
            deleteBook.TabIndex = 35;
            deleteBook.TabStop = false;
            deleteBook.Click += deleteBook_Click;
            // 
            // deleteMovie
            // 
            deleteMovie.Image = Properties.Resources.deleteselected;
            deleteMovie.Location = new Point(644, 353);
            deleteMovie.Name = "deleteMovie";
            deleteMovie.Size = new Size(59, 59);
            deleteMovie.SizeMode = PictureBoxSizeMode.StretchImage;
            deleteMovie.TabIndex = 36;
            deleteMovie.TabStop = false;
            deleteMovie.Click += deleteMovie_Click;
            // 
            // deleteVideogame
            // 
            deleteVideogame.Image = Properties.Resources.deleteselected;
            deleteVideogame.Location = new Point(1025, 353);
            deleteVideogame.Name = "deleteVideogame";
            deleteVideogame.Size = new Size(59, 59);
            deleteVideogame.SizeMode = PictureBoxSizeMode.StretchImage;
            deleteVideogame.TabIndex = 37;
            deleteVideogame.TabStop = false;
            deleteVideogame.Click += deleteVideogame_Click;
            // 
            // refreshButton
            // 
            refreshButton.Image = Properties.Resources.refresh1;
            refreshButton.Location = new Point(12, 12);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(66, 64);
            refreshButton.SizeMode = PictureBoxSizeMode.StretchImage;
            refreshButton.TabIndex = 38;
            refreshButton.TabStop = false;
            refreshButton.Click += refreshButton_Click;
            // 
            // LibraryForm
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1099, 424);
            Controls.Add(refreshButton);
            Controls.Add(deleteVideogame);
            Controls.Add(deleteMovie);
            Controls.Add(deleteBook);
            Controls.Add(videogameInformation);
            Controls.Add(movieInformation);
            Controls.Add(bookInformation);
            Controls.Add(addVideogame);
            Controls.Add(addMovie);
            Controls.Add(addBook);
            Controls.Add(videogameList);
            Controls.Add(movieList);
            Controls.Add(bookList);
            Controls.Add(videogamesLabel);
            Controls.Add(booksLabel);
            Controls.Add(moviesLabel);
            Controls.Add(headerLabel);
            Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.CornflowerBlue;
            Margin = new Padding(6);
            Name = "LibraryForm";
            Text = "Library";
            Load += LibraryForm_Load;
            ((System.ComponentModel.ISupportInitialize)addBook).EndInit();
            ((System.ComponentModel.ISupportInitialize)addMovie).EndInit();
            ((System.ComponentModel.ISupportInitialize)addVideogame).EndInit();
            ((System.ComponentModel.ISupportInitialize)bookInformation).EndInit();
            ((System.ComponentModel.ISupportInitialize)movieInformation).EndInit();
            ((System.ComponentModel.ISupportInitialize)videogameInformation).EndInit();
            ((System.ComponentModel.ISupportInitialize)deleteBook).EndInit();
            ((System.ComponentModel.ISupportInitialize)deleteMovie).EndInit();
            ((System.ComponentModel.ISupportInitialize)deleteVideogame).EndInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label headerLabel;
        private Label moviesLabel;
        private Label booksLabel;
        private Label videogamesLabel;
        private ListBox bookList;
        private ListBox movieList;
        private ListBox videogameList;
        private PictureBox addBook;
        private PictureBox addMovie;
        private PictureBox addVideogame;
        private PictureBox bookInformation;
        private PictureBox movieInformation;
        private PictureBox videogameInformation;
        private PictureBox deleteBook;
        private PictureBox deleteMovie;
        private PictureBox deleteVideogame;
        private PictureBox refreshButton;
    }
}