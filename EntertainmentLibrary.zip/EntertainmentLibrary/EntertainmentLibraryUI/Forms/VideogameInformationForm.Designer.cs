﻿namespace EntertainmentLibraryUI
{
    partial class VideogameInformationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            videogameTitle = new Label();
            supplierName = new Label();
            videogameRating = new Label();
            videogamePlatform = new Label();
            videogameFormat = new Label();
            SuspendLayout();
            // 
            // videogameTitle
            // 
            videogameTitle.AutoSize = true;
            videogameTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            videogameTitle.ForeColor = Color.SlateBlue;
            videogameTitle.Location = new Point(43, 25);
            videogameTitle.Name = "videogameTitle";
            videogameTitle.Size = new Size(316, 54);
            videogameTitle.TabIndex = 2;
            videogameTitle.Text = "videogameTitle";
            // 
            // supplierName
            // 
            supplierName.AutoSize = true;
            supplierName.Location = new Point(12, 309);
            supplierName.Name = "supplierName";
            supplierName.Size = new Size(190, 38);
            supplierName.TabIndex = 9;
            supplierName.Text = "supplierName";
            // 
            // videogameRating
            // 
            videogameRating.AutoSize = true;
            videogameRating.Location = new Point(12, 246);
            videogameRating.Name = "videogameRating";
            videogameRating.Size = new Size(158, 38);
            videogameRating.TabIndex = 8;
            videogameRating.Text = "bookRating";
            // 
            // videogamePlatform
            // 
            videogamePlatform.AutoSize = true;
            videogamePlatform.Location = new Point(12, 177);
            videogamePlatform.Name = "videogamePlatform";
            videogamePlatform.Size = new Size(154, 38);
            videogamePlatform.TabIndex = 7;
            videogamePlatform.Text = "bookGenre";
            // 
            // videogameFormat
            // 
            videogameFormat.AutoSize = true;
            videogameFormat.Location = new Point(12, 115);
            videogameFormat.Name = "videogameFormat";
            videogameFormat.Size = new Size(166, 38);
            videogameFormat.TabIndex = 6;
            videogameFormat.Text = "bookFormat";
            // 
            // VideogameInformationForm
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(396, 394);
            Controls.Add(supplierName);
            Controls.Add(videogameRating);
            Controls.Add(videogamePlatform);
            Controls.Add(videogameFormat);
            Controls.Add(videogameTitle);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.DarkViolet;
            Margin = new Padding(6);
            Name = "VideogameInformationForm";
            Text = "Videogame Information";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label videogameTitle;
        private Label supplierName;
        private Label videogameRating;
        private Label videogamePlatform;
        private Label videogameFormat;
    }
}