﻿namespace EntertainmentLibraryUI
{
    partial class BookInformationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bookTitle = new Label();
            bookFormat = new Label();
            bookGenre = new Label();
            bookRating = new Label();
            supplierName = new Label();
            SuspendLayout();
            // 
            // bookTitle
            // 
            bookTitle.AutoSize = true;
            bookTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            bookTitle.ForeColor = Color.SlateBlue;
            bookTitle.Location = new Point(40, 19);
            bookTitle.Name = "bookTitle";
            bookTitle.Size = new Size(202, 54);
            bookTitle.TabIndex = 1;
            bookTitle.Text = "BookTitle";
            // 
            // bookFormat
            // 
            bookFormat.AutoSize = true;
            bookFormat.Location = new Point(12, 95);
            bookFormat.Name = "bookFormat";
            bookFormat.Size = new Size(166, 38);
            bookFormat.TabIndex = 2;
            bookFormat.Text = "bookFormat";
            // 
            // bookGenre
            // 
            bookGenre.AutoSize = true;
            bookGenre.Location = new Point(12, 153);
            bookGenre.Name = "bookGenre";
            bookGenre.Size = new Size(154, 38);
            bookGenre.TabIndex = 3;
            bookGenre.Text = "bookGenre";
            // 
            // bookRating
            // 
            bookRating.AutoSize = true;
            bookRating.Location = new Point(12, 214);
            bookRating.Name = "bookRating";
            bookRating.Size = new Size(158, 38);
            bookRating.TabIndex = 4;
            bookRating.Text = "bookRating";
            // 
            // supplierName
            // 
            supplierName.AutoSize = true;
            supplierName.Location = new Point(12, 268);
            supplierName.Name = "supplierName";
            supplierName.Size = new Size(190, 38);
            supplierName.TabIndex = 5;
            supplierName.Text = "supplierName";
            // 
            // BookInformationForm
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(289, 368);
            Controls.Add(supplierName);
            Controls.Add(bookRating);
            Controls.Add(bookGenre);
            Controls.Add(bookFormat);
            Controls.Add(bookTitle);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.DarkViolet;
            Margin = new Padding(6);
            Name = "BookInformationForm";
            Text = "Book Information";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label bookTitle;
        private Label bookFormat;
        private Label bookGenre;
        private Label bookRating;
        private Label supplierName;
    }
}