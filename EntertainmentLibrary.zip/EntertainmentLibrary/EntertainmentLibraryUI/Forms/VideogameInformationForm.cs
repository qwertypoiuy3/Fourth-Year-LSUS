﻿using EntertainmentLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntertainmentLibraryUI
{
    public partial class VideogameInformationForm : Form
    {
        public VideogameInformationForm(VideogameModel videogameSelected)
        {
            InitializeComponent();
            videogameTitle.Text = videogameSelected.GameName;
            videogameFormat.Text = "Format: " + videogameSelected.GameFormat;
            videogamePlatform.Text = "Platform: " + videogameSelected.GamePlatform;
            if (videogameSelected.GameRating == null)
            {
                videogameRating.Text = "Rating: " + "0/5";
            }
            else { videogameRating.Text = "Rating: " + videogameSelected.GameRating + "/5"; }
            if (videogameSelected.SupplierName == "")
            {
                supplierName.Text = null;
            }
            else { supplierName.Text = "Supplier: " + videogameSelected.SupplierName; }
            
        }
    }
}
