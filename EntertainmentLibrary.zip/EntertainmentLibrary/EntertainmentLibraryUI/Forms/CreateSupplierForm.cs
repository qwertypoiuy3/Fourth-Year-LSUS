﻿using EntertainmentLibrary.Models;
using EntertainmentLibrary.DataAccess;
using EntertainmentLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntertainmentLibraryUI
{
    public partial class CreateSupplierForm : Form
    {
        private ISupplierRequester callingForm;

        public CreateSupplierForm(ISupplierRequester callingForm)
        {
            InitializeComponent();
            this.callingForm = callingForm;
        }

        private void addSupplierButton_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                SupplierModel model = new SupplierModel(supplierNameValue.Text, urlValue.Text);
                GlobalConfig.Connection.CreateSupplier(model);

                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter a Supplier Name.");
            }
        }
        private bool ValidateForm()
        {
            bool output = true;
            if (supplierNameValue.Text.Length == 0)
            {
                output = false;
            }
            return output;

        }
    }
}
