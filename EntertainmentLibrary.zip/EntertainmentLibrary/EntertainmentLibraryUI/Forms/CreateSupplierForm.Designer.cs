﻿namespace EntertainmentLibraryUI
{
    partial class CreateSupplierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            headerLabel = new Label();
            supplierNameValue = new TextBox();
            supplierNameLabel = new Label();
            urlValue = new TextBox();
            urlLabel = new Label();
            addSupplierButton = new Button();
            SuspendLayout();
            // 
            // headerLabel
            // 
            headerLabel.AutoSize = true;
            headerLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            headerLabel.ForeColor = Color.CornflowerBlue;
            headerLabel.Location = new Point(239, 9);
            headerLabel.Name = "headerLabel";
            headerLabel.Size = new Size(313, 54);
            headerLabel.TabIndex = 23;
            headerLabel.Text = "Create Supplier";
            // 
            // supplierNameValue
            // 
            supplierNameValue.BackColor = Color.Gainsboro;
            supplierNameValue.BorderStyle = BorderStyle.FixedSingle;
            supplierNameValue.Location = new Point(320, 96);
            supplierNameValue.Name = "supplierNameValue";
            supplierNameValue.Size = new Size(318, 47);
            supplierNameValue.TabIndex = 26;
            // 
            // supplierNameLabel
            // 
            supplierNameLabel.AutoSize = true;
            supplierNameLabel.ForeColor = Color.DarkViolet;
            supplierNameLabel.Location = new Point(27, 96);
            supplierNameLabel.Name = "supplierNameLabel";
            supplierNameLabel.Size = new Size(297, 41);
            supplierNameLabel.TabIndex = 25;
            supplierNameLabel.Text = "Enter Supplier Name:";
            // 
            // urlValue
            // 
            urlValue.BackColor = Color.Gainsboro;
            urlValue.BorderStyle = BorderStyle.FixedSingle;
            urlValue.Location = new Point(263, 184);
            urlValue.Name = "urlValue";
            urlValue.Size = new Size(318, 47);
            urlValue.TabIndex = 28;
            // 
            // urlLabel
            // 
            urlLabel.AutoSize = true;
            urlLabel.ForeColor = Color.DarkViolet;
            urlLabel.Location = new Point(179, 186);
            urlLabel.Name = "urlLabel";
            urlLabel.Size = new Size(78, 41);
            urlLabel.TabIndex = 27;
            urlLabel.Text = "URL:";
            // 
            // addSupplierButton
            // 
            addSupplierButton.BackColor = Color.LightGreen;
            addSupplierButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            addSupplierButton.ForeColor = SystemColors.ActiveCaptionText;
            addSupplierButton.Location = new Point(239, 258);
            addSupplierButton.Name = "addSupplierButton";
            addSupplierButton.Size = new Size(270, 78);
            addSupplierButton.TabIndex = 44;
            addSupplierButton.Text = "Add Supplier";
            addSupplierButton.UseVisualStyleBackColor = false;
            addSupplierButton.Click += addSupplierButton_Click;
            // 
            // CreateSupplierForm
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(789, 360);
            Controls.Add(addSupplierButton);
            Controls.Add(urlValue);
            Controls.Add(urlLabel);
            Controls.Add(supplierNameValue);
            Controls.Add(supplierNameLabel);
            Controls.Add(headerLabel);
            Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.CornflowerBlue;
            Margin = new Padding(6);
            Name = "CreateSupplierForm";
            Text = "Create Supplier";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label headerLabel;
        private TextBox supplierNameValue;
        private Label supplierNameLabel;
        private TextBox urlValue;
        private Label urlLabel;
        private Button addSupplierButton;
    }
}