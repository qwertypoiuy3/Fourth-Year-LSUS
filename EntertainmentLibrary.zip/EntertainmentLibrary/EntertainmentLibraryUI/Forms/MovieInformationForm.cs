﻿using EntertainmentLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntertainmentLibraryUI
{
    public partial class MovieInformationForm : Form
    {
        public MovieInformationForm(MovieModel movieSelected)
        {
            InitializeComponent();
            movieTitle.Text = movieSelected.MovieName;
            movieFormat.Text = "Format: " + movieSelected.MovieFormat;
            movieGenre.Text = "Genre: " + movieSelected.MovieGenre;
            if (movieSelected.MovieRating == null)
            {
                movieRating.Text = "Rating: " + "0/5";
            }
            else { movieRating.Text = "Rating: " + movieSelected.MovieRating + "/5"; }
            if (movieSelected.SupplierName == "")
            {
                supplierName.Text = null;
            }
            else { supplierName.Text = "Supplier: " + movieSelected.SupplierName; }
        }
    }
}
