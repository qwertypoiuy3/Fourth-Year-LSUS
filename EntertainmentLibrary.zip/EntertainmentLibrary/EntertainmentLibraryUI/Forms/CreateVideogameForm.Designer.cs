﻿namespace EntertainmentLibraryUI
{
    partial class CreateVideogameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            videogameNameValue = new TextBox();
            videogameNameLabel = new Label();
            headerLabel = new Label();
            videogameFormatLabel = new Label();
            digitalButton = new RadioButton();
            cartridgeButton = new RadioButton();
            discButton = new RadioButton();
            selectPlatformLabel = new Label();
            platformList = new ListBox();
            createNewPlatformLink = new LinkLabel();
            starpic3 = new PictureBox();
            starpic4 = new PictureBox();
            starpic5 = new PictureBox();
            starpic2 = new PictureBox();
            starpic1 = new PictureBox();
            ratingLabel = new Label();
            newSupplierLink = new LinkLabel();
            supplierList = new ComboBox();
            selectSupplierLabel = new Label();
            addVideogameButton = new Button();
            refreshButton = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)starpic3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).BeginInit();
            SuspendLayout();
            // 
            // videogameNameValue
            // 
            videogameNameValue.BackColor = Color.Gainsboro;
            videogameNameValue.BorderStyle = BorderStyle.FixedSingle;
            videogameNameValue.Location = new Point(343, 94);
            videogameNameValue.Name = "videogameNameValue";
            videogameNameValue.Size = new Size(318, 47);
            videogameNameValue.TabIndex = 24;
            // 
            // videogameNameLabel
            // 
            videogameNameLabel.AutoSize = true;
            videogameNameLabel.ForeColor = Color.DarkViolet;
            videogameNameLabel.Location = new Point(12, 94);
            videogameNameLabel.Name = "videogameNameLabel";
            videogameNameLabel.Size = new Size(341, 41);
            videogameNameLabel.TabIndex = 23;
            videogameNameLabel.Text = "Enter Videogame Name:";
            // 
            // headerLabel
            // 
            headerLabel.AutoSize = true;
            headerLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            headerLabel.ForeColor = Color.CornflowerBlue;
            headerLabel.Location = new Point(12, 9);
            headerLabel.Name = "headerLabel";
            headerLabel.Size = new Size(372, 54);
            headerLabel.TabIndex = 22;
            headerLabel.Text = "Create Videogame";
            // 
            // videogameFormatLabel
            // 
            videogameFormatLabel.AutoSize = true;
            videogameFormatLabel.ForeColor = Color.DarkViolet;
            videogameFormatLabel.Location = new Point(12, 171);
            videogameFormatLabel.Name = "videogameFormatLabel";
            videogameFormatLabel.Size = new Size(206, 41);
            videogameFormatLabel.TabIndex = 25;
            videogameFormatLabel.Text = "Select Format:";
            // 
            // digitalButton
            // 
            digitalButton.AutoSize = true;
            digitalButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            digitalButton.ForeColor = Color.RoyalBlue;
            digitalButton.Location = new Point(464, 180);
            digitalButton.Name = "digitalButton";
            digitalButton.Size = new Size(91, 32);
            digitalButton.TabIndex = 28;
            digitalButton.TabStop = true;
            digitalButton.Text = "Digital";
            digitalButton.UseVisualStyleBackColor = true;
            digitalButton.CheckedChanged += blurayButton_CheckedChanged;
            // 
            // cartridgeButton
            // 
            cartridgeButton.AutoSize = true;
            cartridgeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            cartridgeButton.ForeColor = Color.RoyalBlue;
            cartridgeButton.Location = new Point(325, 180);
            cartridgeButton.Name = "cartridgeButton";
            cartridgeButton.Size = new Size(115, 32);
            cartridgeButton.TabIndex = 27;
            cartridgeButton.TabStop = true;
            cartridgeButton.Text = "Cartridge";
            cartridgeButton.UseVisualStyleBackColor = true;
            // 
            // discButton
            // 
            discButton.AutoSize = true;
            discButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            discButton.ForeColor = Color.RoyalBlue;
            discButton.Location = new Point(236, 179);
            discButton.Name = "discButton";
            discButton.Size = new Size(69, 32);
            discButton.TabIndex = 26;
            discButton.TabStop = true;
            discButton.Text = "Disc";
            discButton.UseVisualStyleBackColor = true;
            // 
            // selectPlatformLabel
            // 
            selectPlatformLabel.AutoSize = true;
            selectPlatformLabel.ForeColor = Color.DarkViolet;
            selectPlatformLabel.Location = new Point(12, 241);
            selectPlatformLabel.Name = "selectPlatformLabel";
            selectPlatformLabel.Size = new Size(224, 41);
            selectPlatformLabel.TabIndex = 29;
            selectPlatformLabel.Text = "Select Platform:";
            // 
            // platformList
            // 
            platformList.BackColor = Color.Gainsboro;
            platformList.BorderStyle = BorderStyle.FixedSingle;
            platformList.ForeColor = Color.DarkBlue;
            platformList.FormattingEnabled = true;
            platformList.ItemHeight = 41;
            platformList.Items.AddRange(new object[] { "PS4", "PS5", "XBOX ONE", "XBOX SERIES", "NINTENDO SWITCH", "PC" });
            platformList.Location = new Point(12, 285);
            platformList.Name = "platformList";
            platformList.Size = new Size(321, 248);
            platformList.TabIndex = 30;
            // 
            // createNewPlatformLink
            // 
            createNewPlatformLink.AutoSize = true;
            createNewPlatformLink.Location = new Point(12, 536);
            createNewPlatformLink.Name = "createNewPlatformLink";
            createNewPlatformLink.Size = new Size(292, 41);
            createNewPlatformLink.TabIndex = 31;
            createNewPlatformLink.TabStop = true;
            createNewPlatformLink.Text = "Create New Platform";
            createNewPlatformLink.LinkClicked += createNewPlatformLink_LinkClicked;
            // 
            // starpic3
            // 
            starpic3.Image = Properties.Resources.whitestar;
            starpic3.Location = new Point(635, 253);
            starpic3.Name = "starpic3";
            starpic3.Size = new Size(43, 38);
            starpic3.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic3.TabIndex = 39;
            starpic3.TabStop = false;
            starpic3.Click += starPic3_Click;
            // 
            // starpic4
            // 
            starpic4.Image = Properties.Resources.whitestar;
            starpic4.Location = new Point(684, 253);
            starpic4.Name = "starpic4";
            starpic4.Size = new Size(43, 38);
            starpic4.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic4.TabIndex = 38;
            starpic4.TabStop = false;
            starpic4.Click += starPic4_Click;
            // 
            // starpic5
            // 
            starpic5.Image = Properties.Resources.whitestar;
            starpic5.Location = new Point(733, 253);
            starpic5.Name = "starpic5";
            starpic5.Size = new Size(43, 38);
            starpic5.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic5.TabIndex = 37;
            starpic5.TabStop = false;
            starpic5.Click += starpic5_Click;
            // 
            // starpic2
            // 
            starpic2.Image = Properties.Resources.whitestar;
            starpic2.Location = new Point(586, 253);
            starpic2.Name = "starpic2";
            starpic2.Size = new Size(43, 38);
            starpic2.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic2.TabIndex = 36;
            starpic2.TabStop = false;
            starpic2.Click += starPic2_Click;
            // 
            // starpic1
            // 
            starpic1.Image = Properties.Resources.whitestar;
            starpic1.Location = new Point(537, 253);
            starpic1.Name = "starpic1";
            starpic1.Size = new Size(43, 38);
            starpic1.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic1.TabIndex = 35;
            starpic1.TabStop = false;
            starpic1.Click += starPic1_Click;
            // 
            // ratingLabel
            // 
            ratingLabel.AutoSize = true;
            ratingLabel.ForeColor = Color.DarkViolet;
            ratingLabel.Location = new Point(421, 250);
            ratingLabel.Name = "ratingLabel";
            ratingLabel.Size = new Size(110, 41);
            ratingLabel.TabIndex = 34;
            ratingLabel.Text = "Rating:";
            // 
            // newSupplierLink
            // 
            newSupplierLink.AutoSize = true;
            newSupplierLink.Location = new Point(442, 400);
            newSupplierLink.Name = "newSupplierLink";
            newSupplierLink.Size = new Size(258, 41);
            newSupplierLink.TabIndex = 42;
            newSupplierLink.TabStop = true;
            newSupplierLink.Text = "Add New Supplier";
            newSupplierLink.LinkClicked += newSupplierLink_LinkClicked;
            // 
            // supplierList
            // 
            supplierList.BackColor = Color.Gainsboro;
            supplierList.DropDownStyle = ComboBoxStyle.DropDownList;
            supplierList.FormattingEnabled = true;
            supplierList.Location = new Point(557, 338);
            supplierList.Name = "supplierList";
            supplierList.Size = new Size(271, 49);
            supplierList.TabIndex = 41;
            // 
            // selectSupplierLabel
            // 
            selectSupplierLabel.AutoSize = true;
            selectSupplierLabel.ForeColor = Color.DarkViolet;
            selectSupplierLabel.Location = new Point(345, 341);
            selectSupplierLabel.Name = "selectSupplierLabel";
            selectSupplierLabel.Size = new Size(221, 41);
            selectSupplierLabel.TabIndex = 40;
            selectSupplierLabel.Text = "Select Supplier:";
            // 
            // addVideogameButton
            // 
            addVideogameButton.BackColor = Color.LightGreen;
            addVideogameButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            addVideogameButton.ForeColor = SystemColors.ActiveCaptionText;
            addVideogameButton.Location = new Point(484, 499);
            addVideogameButton.Name = "addVideogameButton";
            addVideogameButton.Size = new Size(270, 78);
            addVideogameButton.TabIndex = 43;
            addVideogameButton.Text = "Add Videogame";
            addVideogameButton.UseVisualStyleBackColor = false;
            addVideogameButton.Click += addVideogameButton_Click;
            // 
            // refreshButton
            // 
            refreshButton.Image = Properties.Resources.refresh1;
            refreshButton.Location = new Point(790, 9);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(66, 64);
            refreshButton.SizeMode = PictureBoxSizeMode.StretchImage;
            refreshButton.TabIndex = 44;
            refreshButton.TabStop = false;
            refreshButton.Click += refreshButton_Click;
            // 
            // CreateVideogameForm
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(868, 625);
            Controls.Add(refreshButton);
            Controls.Add(addVideogameButton);
            Controls.Add(newSupplierLink);
            Controls.Add(supplierList);
            Controls.Add(selectSupplierLabel);
            Controls.Add(starpic3);
            Controls.Add(starpic4);
            Controls.Add(starpic5);
            Controls.Add(starpic2);
            Controls.Add(starpic1);
            Controls.Add(ratingLabel);
            Controls.Add(createNewPlatformLink);
            Controls.Add(platformList);
            Controls.Add(selectPlatformLabel);
            Controls.Add(digitalButton);
            Controls.Add(cartridgeButton);
            Controls.Add(discButton);
            Controls.Add(videogameFormatLabel);
            Controls.Add(videogameNameValue);
            Controls.Add(videogameNameLabel);
            Controls.Add(headerLabel);
            Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.CornflowerBlue;
            Margin = new Padding(6);
            Name = "CreateVideogameForm";
            Text = "Create Videogame";
            ((System.ComponentModel.ISupportInitialize)starpic3).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic4).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic5).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic2).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic1).EndInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox videogameNameValue;
        private Label videogameNameLabel;
        private Label headerLabel;
        private Label videogameFormatLabel;
        private RadioButton digitalButton;
        private RadioButton cartridgeButton;
        private RadioButton discButton;
        private Label selectPlatformLabel;
        private ListBox platformList;
        private LinkLabel createNewPlatformLink;
        private PictureBox starpic3;
        private PictureBox starpic4;
        private PictureBox starpic5;
        private PictureBox starpic2;
        private PictureBox starpic1;
        private Label ratingLabel;
        private LinkLabel newSupplierLink;
        private ComboBox supplierList;
        private Label selectSupplierLabel;
        private Button addVideogameButton;
        private PictureBox refreshButton;
    }
}