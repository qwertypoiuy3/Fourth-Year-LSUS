﻿namespace EntertainmentLibraryUI
{
    partial class CreateMovieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addMovieButton = new Button();
            newSupplierLink = new LinkLabel();
            supplierList = new ComboBox();
            selectSupplierLabel = new Label();
            starpic3 = new PictureBox();
            starpic4 = new PictureBox();
            starpic5 = new PictureBox();
            starpic2 = new PictureBox();
            starpic1 = new PictureBox();
            ratingLabel = new Label();
            movieGenreValue = new TextBox();
            movieGenreLabel = new Label();
            blurayButton = new RadioButton();
            dvdButton = new RadioButton();
            vhsButton = new RadioButton();
            movieFormatLabel = new Label();
            movieNameValue = new TextBox();
            movieNameLabel = new Label();
            headerLabel = new Label();
            uhdButton = new RadioButton();
            digitalButton = new RadioButton();
            refreshButton = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)starpic3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)starpic1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).BeginInit();
            SuspendLayout();
            // 
            // addMovieButton
            // 
            addMovieButton.BackColor = Color.PaleGreen;
            addMovieButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            addMovieButton.ForeColor = SystemColors.ActiveCaptionText;
            addMovieButton.Location = new Point(555, 472);
            addMovieButton.Name = "addMovieButton";
            addMovieButton.Size = new Size(205, 65);
            addMovieButton.TabIndex = 37;
            addMovieButton.Text = "Add Movie";
            addMovieButton.UseVisualStyleBackColor = false;
            addMovieButton.Click += addMovieButton_Click;
            // 
            // newSupplierLink
            // 
            newSupplierLink.AutoSize = true;
            newSupplierLink.Location = new Point(103, 496);
            newSupplierLink.Name = "newSupplierLink";
            newSupplierLink.Size = new Size(258, 41);
            newSupplierLink.TabIndex = 36;
            newSupplierLink.TabStop = true;
            newSupplierLink.Text = "Add New Supplier";
            newSupplierLink.LinkClicked += newSupplierLink_LinkClicked;
            // 
            // supplierList
            // 
            supplierList.BackColor = Color.Gainsboro;
            supplierList.DropDownStyle = ComboBoxStyle.DropDownList;
            supplierList.FormattingEnabled = true;
            supplierList.Location = new Point(220, 434);
            supplierList.Name = "supplierList";
            supplierList.Size = new Size(271, 49);
            supplierList.TabIndex = 35;
            // 
            // selectSupplierLabel
            // 
            selectSupplierLabel.AutoSize = true;
            selectSupplierLabel.ForeColor = Color.DarkViolet;
            selectSupplierLabel.Location = new Point(6, 437);
            selectSupplierLabel.Name = "selectSupplierLabel";
            selectSupplierLabel.Size = new Size(221, 41);
            selectSupplierLabel.TabIndex = 34;
            selectSupplierLabel.Text = "Select Supplier:";
            // 
            // starpic3
            // 
            starpic3.Image = Properties.Resources.whitestar;
            starpic3.Location = new Point(220, 367);
            starpic3.Name = "starpic3";
            starpic3.Size = new Size(43, 38);
            starpic3.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic3.TabIndex = 33;
            starpic3.TabStop = false;
            starpic3.Click += starPic3_Click;
            // 
            // starpic4
            // 
            starpic4.Image = Properties.Resources.whitestar;
            starpic4.Location = new Point(269, 367);
            starpic4.Name = "starpic4";
            starpic4.Size = new Size(43, 38);
            starpic4.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic4.TabIndex = 32;
            starpic4.TabStop = false;
            starpic4.Click += starPic4_Click;
            // 
            // starpic5
            // 
            starpic5.Image = Properties.Resources.whitestar;
            starpic5.Location = new Point(318, 367);
            starpic5.Name = "starpic5";
            starpic5.Size = new Size(43, 38);
            starpic5.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic5.TabIndex = 31;
            starpic5.TabStop = false;
            starpic5.Click += starpic5_Click;
            // 
            // starpic2
            // 
            starpic2.Image = Properties.Resources.whitestar;
            starpic2.Location = new Point(171, 367);
            starpic2.Name = "starpic2";
            starpic2.Size = new Size(43, 38);
            starpic2.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic2.TabIndex = 30;
            starpic2.TabStop = false;
            starpic2.Click += starPic2_Click;
            // 
            // starpic1
            // 
            starpic1.Image = Properties.Resources.whitestar;
            starpic1.Location = new Point(122, 367);
            starpic1.Name = "starpic1";
            starpic1.Size = new Size(43, 38);
            starpic1.SizeMode = PictureBoxSizeMode.StretchImage;
            starpic1.TabIndex = 29;
            starpic1.TabStop = false;
            starpic1.Click += starPic1_Click;
            // 
            // ratingLabel
            // 
            ratingLabel.AutoSize = true;
            ratingLabel.ForeColor = Color.DarkViolet;
            ratingLabel.Location = new Point(6, 364);
            ratingLabel.Name = "ratingLabel";
            ratingLabel.Size = new Size(110, 41);
            ratingLabel.TabIndex = 28;
            ratingLabel.Text = "Rating:";
            // 
            // movieGenreValue
            // 
            movieGenreValue.BackColor = Color.Gainsboro;
            movieGenreValue.BorderStyle = BorderStyle.FixedSingle;
            movieGenreValue.Location = new Point(269, 275);
            movieGenreValue.Name = "movieGenreValue";
            movieGenreValue.Size = new Size(318, 47);
            movieGenreValue.TabIndex = 27;
            // 
            // movieGenreLabel
            // 
            movieGenreLabel.AutoSize = true;
            movieGenreLabel.ForeColor = Color.DarkViolet;
            movieGenreLabel.Location = new Point(6, 275);
            movieGenreLabel.Name = "movieGenreLabel";
            movieGenreLabel.Size = new Size(271, 41);
            movieGenreLabel.TabIndex = 26;
            movieGenreLabel.Text = "Enter Movie Genre:";
            // 
            // blurayButton
            // 
            blurayButton.AutoSize = true;
            blurayButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            blurayButton.ForeColor = Color.RoyalBlue;
            blurayButton.Location = new Point(416, 194);
            blurayButton.Name = "blurayButton";
            blurayButton.Size = new Size(92, 32);
            blurayButton.TabIndex = 25;
            blurayButton.TabStop = true;
            blurayButton.Text = "BluRay";
            blurayButton.UseVisualStyleBackColor = true;
            // 
            // dvdButton
            // 
            dvdButton.AutoSize = true;
            dvdButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dvdButton.ForeColor = Color.RoyalBlue;
            dvdButton.Location = new Point(318, 195);
            dvdButton.Name = "dvdButton";
            dvdButton.Size = new Size(73, 32);
            dvdButton.TabIndex = 24;
            dvdButton.TabStop = true;
            dvdButton.Text = "DVD";
            dvdButton.UseVisualStyleBackColor = true;
            // 
            // vhsButton
            // 
            vhsButton.AutoSize = true;
            vhsButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            vhsButton.ForeColor = Color.RoyalBlue;
            vhsButton.Location = new Point(231, 195);
            vhsButton.Name = "vhsButton";
            vhsButton.Size = new Size(70, 32);
            vhsButton.TabIndex = 23;
            vhsButton.TabStop = true;
            vhsButton.Text = "VHS";
            vhsButton.UseVisualStyleBackColor = true;
            // 
            // movieFormatLabel
            // 
            movieFormatLabel.AutoSize = true;
            movieFormatLabel.ForeColor = Color.DarkViolet;
            movieFormatLabel.Location = new Point(6, 186);
            movieFormatLabel.Name = "movieFormatLabel";
            movieFormatLabel.Size = new Size(206, 41);
            movieFormatLabel.TabIndex = 22;
            movieFormatLabel.Text = "Select Format:";
            // 
            // movieNameValue
            // 
            movieNameValue.BackColor = Color.Gainsboro;
            movieNameValue.BorderStyle = BorderStyle.FixedSingle;
            movieNameValue.Location = new Point(268, 94);
            movieNameValue.Name = "movieNameValue";
            movieNameValue.Size = new Size(318, 47);
            movieNameValue.TabIndex = 21;
            // 
            // movieNameLabel
            // 
            movieNameLabel.AutoSize = true;
            movieNameLabel.ForeColor = Color.DarkViolet;
            movieNameLabel.Location = new Point(6, 94);
            movieNameLabel.Name = "movieNameLabel";
            movieNameLabel.Size = new Size(270, 41);
            movieNameLabel.TabIndex = 20;
            movieNameLabel.Text = "Enter Movie Name:";
            // 
            // headerLabel
            // 
            headerLabel.AutoSize = true;
            headerLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            headerLabel.ForeColor = Color.CornflowerBlue;
            headerLabel.Location = new Point(6, 9);
            headerLabel.Name = "headerLabel";
            headerLabel.Size = new Size(274, 54);
            headerLabel.TabIndex = 19;
            headerLabel.Text = "Create Movie";
            // 
            // uhdButton
            // 
            uhdButton.AutoSize = true;
            uhdButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uhdButton.ForeColor = Color.RoyalBlue;
            uhdButton.Location = new Point(532, 195);
            uhdButton.Name = "uhdButton";
            uhdButton.Size = new Size(120, 32);
            uhdButton.TabIndex = 38;
            uhdButton.TabStop = true;
            uhdButton.Text = "4K BluRay";
            uhdButton.UseVisualStyleBackColor = true;
            // 
            // digitalButton
            // 
            digitalButton.AutoSize = true;
            digitalButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            digitalButton.ForeColor = Color.RoyalBlue;
            digitalButton.Location = new Point(669, 195);
            digitalButton.Name = "digitalButton";
            digitalButton.Size = new Size(91, 32);
            digitalButton.TabIndex = 39;
            digitalButton.TabStop = true;
            digitalButton.Text = "Digital";
            digitalButton.UseVisualStyleBackColor = true;
            // 
            // refreshButton
            // 
            refreshButton.Image = Properties.Resources.refresh1;
            refreshButton.Location = new Point(742, 12);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(66, 64);
            refreshButton.SizeMode = PictureBoxSizeMode.StretchImage;
            refreshButton.TabIndex = 45;
            refreshButton.TabStop = false;
            refreshButton.Click += refreshButton_Click;
            // 
            // CreateMovieForm
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(820, 554);
            Controls.Add(refreshButton);
            Controls.Add(digitalButton);
            Controls.Add(uhdButton);
            Controls.Add(addMovieButton);
            Controls.Add(newSupplierLink);
            Controls.Add(supplierList);
            Controls.Add(selectSupplierLabel);
            Controls.Add(starpic3);
            Controls.Add(starpic4);
            Controls.Add(starpic5);
            Controls.Add(starpic2);
            Controls.Add(starpic1);
            Controls.Add(ratingLabel);
            Controls.Add(movieGenreValue);
            Controls.Add(movieGenreLabel);
            Controls.Add(blurayButton);
            Controls.Add(dvdButton);
            Controls.Add(vhsButton);
            Controls.Add(movieFormatLabel);
            Controls.Add(movieNameValue);
            Controls.Add(movieNameLabel);
            Controls.Add(headerLabel);
            Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(7, 6, 7, 6);
            Name = "CreateMovieForm";
            Text = "Create Movie";
            Load += CreateMovieForm_Load;
            ((System.ComponentModel.ISupportInitialize)starpic3).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic4).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic5).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic2).EndInit();
            ((System.ComponentModel.ISupportInitialize)starpic1).EndInit();
            ((System.ComponentModel.ISupportInitialize)refreshButton).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button addMovieButton;
        private LinkLabel newSupplierLink;
        private ComboBox supplierList;
        private Label selectSupplierLabel;
        private PictureBox starpic3;
        private PictureBox starpic4;
        private PictureBox starpic5;
        private PictureBox starpic2;
        private PictureBox starpic1;
        private Label ratingLabel;
        private TextBox movieGenreValue;
        private Label movieGenreLabel;
        private RadioButton blurayButton;
        private RadioButton dvdButton;
        private RadioButton vhsButton;
        private Label movieFormatLabel;
        private TextBox movieNameValue;
        private Label movieNameLabel;
        private Label headerLabel;
        private RadioButton uhdButton;
        private RadioButton digitalButton;
        private PictureBox refreshButton;
    }
}